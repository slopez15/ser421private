/*
this shows format,
should not be in a file and refd as variable, but instead....
this data should be saved to browser local storage
the data that is being dealt with should be in session storage aka runningDialogue.
*/
var userData =
{
  "data":[
    {
      "name": "james",
      "dialogue":{
        "1":"Hi there! What's your name?",
        "2":"My name is james.",
        "4":"I like baseball",
        "5":"Nice to meet you James."
      }
    },
    {
      "name": "jacob",
    },
    {
      "name": "harrison",
    },
    {
      "name": "mike",
    }
  ]
};
