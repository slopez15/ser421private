// var responseGenerator = require('./responseGenerator.js');
/* Note:
userData.json and default.json
should be either public (imported as global variables for scripts), or
local/session (stored on client)
*/
function App() {
  //Attributes
  this.name = "";
  this.runningDialogue = ""; //json conversation of certain user.
  this.state = 0; //0=encounter (new or after clear), 1=greeting, 2=entries ("loops"), 4=clear? all events on hold?

//Functions
  //print onto <div id="dialogue">
  App.prototype.displayDialogue = function () {
    //convert runningDialogue into string.
    var runningDialogueString = "hello";

    //overwrite particular Dom element to print runningDialogueString
    var dialogue_p = document.getElementById("dialogue p");
    dialogue_p.textContent = this.runningDialogue;
  }
  //set conversation into userData as specific user or overwrite it.
  App.prototype.saveConversation = function (name = this.name) {
    console.log(name);
  }

  //get user specific convo, if exist.
  App.prototype.restoreConversation = function (name = this.name) {
    //restore if prior respondent
    console.log(name);
  }
  //clear -- clear user spdicific data and change state=0.
  App.prototype.clearConversation = function (name = this.name) {
    console.log(name);
  }

  //respond depending on app state.
  App.prototype.generateResponse = function (name = this.name) {
    //after each eliza responses, save converse and displayDialogue
    console.log("test1");
    switch (this.state) {
      case 0:  //0=encounter
        console.log("test - 0");
        //ask for his/her name at startup. "encounter"
        this.runningDialogue += responseGenerator.encounter();
        this.state += 1;
        break;
      case 1:  //1=greeting
      console.log("test - 1");
        //if name entered, greet user and restore conversation (if user exists).
        this.runningDialogue += responseGenerator.greetings();
        // this.restoreConversation();
        this.state += 1;
        break;
      case 2:  //2=entries
      console.log("test - 2");
        //anything after just loop with entires eliza responses based on user responses.
        this.runningDialogue += responseGenerator.entries();
        break;
      default:
        console.log("error: invalid state");
    }
    // this.saveConversation();
    this.displayDialogue();

    //restoreConversation if already met user and print runningDialogue.
    //start with "greetings", then "entries"
    // else {
    //   //
    // }
  console.log("test2");
  }


  //code to run when initiated.
  this.generateResponse(); //encounter
  this.displayDialogue(); //initial dialogue history
}
var app = new App();

/*
make this a
event driven state<<
not looping state << no need to constantly run.
*/
