var responseGenerator = {
  "encounter": function () {
    // body...
    return "encounter";
  },
  "greetings": function () {
    // body...
    return "greetings";
  },
  "entries": function () {
    // body...
    return "entries";
  }
};
