/*
story permissions
public
//1=public, 2=public and private, 3=public and privately author.
//Guest=1; Subscriber=2; Author=3;
*/
function Guest (){
  this.storPermissions=1;
}
