var homePage = require('./home');
var failPage = require('./fail');
var viewnewsPage = require('./viewnews');
var makestoryPage = require('./makestory');












module.exports = {homePage, failPage, viewnewsPage, makestoryPage};
