inform about design.

I placed files in folders to be easier to manage application and future modification.
Persistence.
  There is an example WorldModel.json.
  Any other files must be formatted in same manner as WorldModel.json before being used as a means of persistence.
EC
  Did not do async
  nor mongoDB/mysql. wrote in json file.
Endpoints/Methods
  //


//
