lab 5 needs to continue off of lab3act1--used kgary sol as start for it.
activity1
  **how to run?
    `npm run start` in activity1
    OR
    `npm run activity1` in slopez15_lab
  started on server first then build the client side.
  client side
    temporary used calc exmple and then replace with ajax example (as proof of concept) then will replace with my material for lab.
    The main idea:
      Should provide a HTML file with included scripts.
      Scripts have Ajax calls to server API to get data, and scripts will manipulate for DOM manipulation.
      Unlike, calc base where each server route will provide a new whole html page formatted based on data. (eg. render views and view controller in server.)
      So, no view render should exist in server. Just provide one static html w/ scripts (see 1st sentence).
activity2
  same as activity1 but rename with activity2

.





//
